package main.controller;

import main.config.JWTGenerator;
import main.dto.LoginDTO;
import main.dto.RegisterDTO;
import main.dto.UserDTO;
import main.model.User;
import main.service.IRolesService;
import main.service.IUsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private IUsersService usersService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JWTGenerator jwtGenerator;

    @Autowired
    private IRolesService rolesService;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("registerDTO", new RegisterDTO());
        return "register";
    }

    @PostMapping("/register")
    private String registerUser(@ModelAttribute RegisterDTO registerDTO, Model model) {
        model.addAttribute("registerDTO", registerDTO);

        User user = new User();
        user.setUsername(registerDTO.getUsername());
        user.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        user.setRole(rolesService.getRoleById(1L));

        try{
            usersService.addUser(user);
            System.out.println(user.getUsername() + " " + user.getPassword());
        }catch(Exception e) {
            System.out.println("User cannot be registered! " + e.getMessage());
            return "register";
        }
        return "redirect:/auth/login";
    }

    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("loginDTO", new LoginDTO());
        return "login";
    }

    @PostMapping("/login")
    private ResponseEntity<String> login(@ModelAttribute LoginDTO loginDTO,
                       HttpServletRequest request, HttpServletResponse response, Model model) throws IOException, ServletException {
        model.addAttribute("loginDTO", loginDTO);
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginDTO.getUsername(),
                            loginDTO.getPassword()));

            SecurityContextHolder.getContext().setAuthentication(authentication);
            String token = jwtGenerator.generateToken(authentication);
            System.out.println("Login success! Token: " + token);
            return ResponseEntity.ok().body(token);

        }catch(AuthenticationException e/*ServletException e*/) {
            System.out.println("Cannot log in! " + e.getMessage());
            return ResponseEntity.badRequest().body("Login failed");
        }
    }

}
