package main.controller;

import main.dto.RoleDTO;
import main.model.Role;
import main.service.IRolesService;
import main.utils.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class RolesController {
    @Autowired
    IRolesService rolesService;

    @GetMapping("/roles")
    private ResponseEntity<List<RoleDTO>> getAllRoles() {
        try {
            List<Role> roles = rolesService.getRoles();

            if(roles == null || roles.isEmpty())
                return ResponseEntity.noContent().build();

            List<RoleDTO> roleDTOS = Util.mapRoleToRoleDTO(roles);

            return ResponseEntity.ok().body(roleDTOS);
        }catch(Exception e) {
            System.out.println(e.getMessage());
            return ResponseEntity.internalServerError().body(null);
        }
    }
    @PostMapping("/createrole")
    private ResponseEntity<List<RoleDTO>> createRole(@RequestBody RoleDTO roleDTO) {
        try {
            Role role = new Role();
            role.setId(roleDTO.getId());
            role.setName(roleDTO.getName());

            rolesService.addRole(role);

            List<Role> roles = rolesService.getRoles();
            if(roles == null || roles.isEmpty())
                return ResponseEntity.noContent().build();

            List<RoleDTO> roleDTOS = Util.mapRoleToRoleDTO(roles);

            return ResponseEntity.ok().body(roleDTOS);
        }
        catch(Exception e) {
            System.out.println(e.getMessage());
            return ResponseEntity.internalServerError().body(null);
        }
    }

    @PutMapping("/updaterole/{id}")
    private ResponseEntity<RoleDTO> updateRole(@PathVariable("id") Long id, @RequestBody RoleDTO roleDTO) {
        try {
            roleDTO.setId(id);

            Role role = new Role();
            role.setId(id);
            role.setName(roleDTO.getName());

            rolesService.updateRole(role);
            return ResponseEntity.ok().body(roleDTO);
        }
        catch(Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }

    @GetMapping("/roles/id/{id}")
    private ResponseEntity<RoleDTO> getRoleById(@PathVariable("id") Long id) {
        try {
            Role role = rolesService.getRoleById(id);

            RoleDTO roleDTO = new RoleDTO();
            roleDTO.setId(role.getId());
            roleDTO.setName(role.getName());

            if(role == null) {
                return ResponseEntity.notFound().build();
            }

            return ResponseEntity.ok().body(roleDTO);

        }catch(Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }

    @GetMapping("roles/name/{name}")
    private ResponseEntity<RoleDTO> getRoleByName(@PathVariable("name") String name) {
        try {
            Role role = rolesService.getRoleByName(name);

            if(role == null)
                return ResponseEntity.notFound().build();

            RoleDTO roleDTO = new RoleDTO();
            roleDTO.setId(role.getId());
            roleDTO.setName(role.getName());

            return ResponseEntity.ok().body(roleDTO);

        }catch(Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }


}
