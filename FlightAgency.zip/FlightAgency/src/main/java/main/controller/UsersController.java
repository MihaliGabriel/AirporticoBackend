package main.controller;

import main.dto.UserDTO;
import main.model.User;
import main.service.IRolesService;
import main.service.IUsersService;
import main.utils.Util;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Controller
public class UsersController {

    @Autowired
    IUsersService usersService;

    @Autowired
    IRolesService rolesService;

    @GetMapping("/users")
    private ResponseEntity<List<UserDTO>> getAllUsers() {
        try {
            List<User> users = usersService.getUsers();
            if (users == null && users.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            List<UserDTO> userDTOS = Util.mapUserToUserDTO(users);
            return new ResponseEntity<>(userDTOS, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/users/id/{id}")
    private ResponseEntity<UserDTO> getUserById(@PathVariable("id") long id) {
        try {
            User user = usersService.getUserById(id);
            if(user == null) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            else {
                UserDTO userDTO = new UserDTO(user.getId(), user.getUsername(), user.getPassword(), user.getRole().getName());
                return new ResponseEntity<>(userDTO, HttpStatus.OK);
            }
        }catch(Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/users/username/{username}")
        private ResponseEntity<UserDTO> getUserByUsername(@PathVariable("username") String username) {
        try {
            User user = usersService.getUserByUsername(username);
            UserDTO userDTO = new UserDTO(user.getId(), user.getUsername(), user.getPassword(), user.getRole().getName());
            if (user == null) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            } else {
                return new ResponseEntity<>(userDTO, HttpStatus.OK);
            }
        } catch(Exception e) {
            System.out.println(e.getMessage() + " Username " + username);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/createuser")
    private ResponseEntity<List<UserDTO>> createUser(@RequestBody UserDTO userDTO) {
        try {
            User user = new User();
            user.setUsername(userDTO.getUsername());
            user.setPassword(userDTO.getPassword());
            user.setRole(rolesService.getRoleByName(userDTO.getRoleName()));

            usersService.addUser(user);

            List<User> users = usersService.getUsers();


            if(users == null || users.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            List<UserDTO> userDTOS = Util.mapUserToUserDTO(users);
            System.out.println("user added");
            return ResponseEntity.status(HttpStatus.OK).body(userDTOS);
        }
        catch(Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @DeleteMapping("/deleteuser/{id}")
    private ResponseEntity<List<UserDTO>> deleteUser(@PathVariable("id") long id) {
        try {
            usersService.deleteUserById(id);
            List<User> users = usersService.getUsers();
            if(users == null || users.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            List<UserDTO> userDTOS = Util.mapUserToUserDTO(users);
            return new ResponseEntity<>(userDTOS, HttpStatus.OK);
        }
        catch(Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/updateuser/{id}")
    private ResponseEntity<UserDTO> updateUser(@PathVariable("id") long id, @RequestBody UserDTO userDTO) {
        try {
                User user = new User();

                userDTO.setId(id);
                user.setId(userDTO.getId());
                user.setUsername(userDTO.getUsername());
                user.setPassword(userDTO.getPassword());
                user.setRole(rolesService.getRoleByName(userDTO.getRoleName()));

                usersService.updateUser(user);
                return new ResponseEntity<>(userDTO, HttpStatus.OK);
        }
        catch(Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/fetchusers")
    private String showListUsersAdmin(Model model) throws IOException {
        model.addAttribute("listUsers", new UserDTO());
        return "console";
    }
    @PostMapping(value = "/fetchusers")
    private String listUsersAdmin(Model model,
                                  HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<User> listUsers = usersService.getUsers();
        model.addAttribute("listUsers", listUsers);
        System.out.println("Users list was added");

        return "console";
    }


}
