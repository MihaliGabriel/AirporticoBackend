package main.model;

import javax.persistence.*;

@Entity
@Table(name="flights")
public class Flight {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="flight_name", length=100, unique = true, nullable = false)
    private String name;

    @Column(name="flight_seats", unique = false, nullable = false)
    private Integer seats;

}
