package main.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class DBService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DBService.class);

    public void someDatabaseOperation() {
//        SessionFactory sessionFactory = config.HibernateSessionFactory.getSessionFactory();
//        Session session = sessionFactory.openSession();
//        Transaction tx = null;
//
//        try {
//            tx = session.beginTransaction();
//
//            Role role = new Role();
//            User user = new User();
//            tx.commit();
//            LOGGER.info("user_id={} username={} password={} ref_role={}", user.getId(), user.getUsername(), user.getPassword(), user.getRole().getId());
//        } catch (Exception e) {
//            if (tx != null) {
//                tx.rollback();
//            }
//            LOGGER.error("Error during database operation: ", e);
//        } finally {
//            session.close();
//        }
    }
}

