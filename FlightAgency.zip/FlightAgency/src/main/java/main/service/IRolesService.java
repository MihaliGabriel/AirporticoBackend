package main.service;

import main.model.Role;

import java.util.List;

public interface IRolesService {
    List<Role> getRoles();
    void addRole(Role role);
    Role getRoleById(Long id);
    Role getRoleByName(String name);
    void updateRole(Role role);

}
