package main.service;

import main.dto.UserDTO;
import main.model.User;

import java.util.List;

public interface IUsersService {
    public List<User> getUsers();
    public void addUser(User user);
    public User getUserById(Long id);
    public User getUserByUsername(String username);
    public void deleteUserById(Long id);
    public void updateUser(User user);
}
