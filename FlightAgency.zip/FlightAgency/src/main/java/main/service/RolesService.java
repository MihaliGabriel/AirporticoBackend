package main.service;

import main.model.Role;
import main.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class RolesService implements IRolesService {

    @Autowired
    private RoleRepository roleRepository;

    public List<Role> getRoles() {
        List<Role> roles = roleRepository.findAll();
        System.out.println(roles);
        return roles;
    }
    public void addRole(Role role) {
        roleRepository.save(role);
    }
    public Role getRoleById(Long id) {
        Role role = roleRepository.getById(id);
        return role;
    }

    @Override
    public Role getRoleByName(String name) {
        return roleRepository.findByName(name);
    }

    public void updateRole(Role role) {
        roleRepository.save(role);
    }

}
