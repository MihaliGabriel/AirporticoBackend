package main.service;

import main.dto.UserDTO;
import main.model.User;
import main.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service
public class UsersService implements IUsersService {

    @Autowired
    public UserRepository userRepository;

    private void checkUniqueUsername(String username, String type) throws Exception{
        Long count = userRepository.countByUsername(username);
        if(count != 0 && type.equals("INSERT"))
            throw new Exception("Username not unique");
        if(count > 1 && type.equals("UPDATE")) {
            throw new Exception("Username not unique");
        }
    }
    private void checkNullUsername(String username) throws Exception{
        if(username == null)
            throw new Exception("Username is null");
    }
    public void addUser(User user) {
        try {
            checkNullUsername(user.getUsername());
            checkUniqueUsername(user.getUsername(), "insert");
            userRepository.save(user);
            System.out.println("Inserted user");
        } catch (Exception e) {
            System.out.println("Invalid user: " + e.getMessage());
        }
    }
    public List<User> getUsers() {
        List<User> users = userRepository.findAll();
        System.out.println(users);
        return users;
    }

    public User getUserByUsername(String username) {
        User user = userRepository.findByUsername(username);
        return user;
    }
    public User getUserById(Long id) {
        User user = userRepository.getById(id);
        return user;
    }

    public void deleteUserById(Long id) {
        userRepository.deleteById(id);
    }

    public void updateUser(User user) {
        try {
            checkNullUsername(user.getUsername());
            checkUniqueUsername(user.getUsername(), "UPDATE");
            userRepository.save(user);
        }catch(Exception e) {
            e.getMessage();
        }

    }
}
