package main.utils;

import main.dto.RoleDTO;
import main.dto.UserDTO;
import main.model.Role;
import main.model.User;

import java.util.ArrayList;
import java.util.List;

public class Util {
    public static Long getLong(Object number) {

        if (number == null) {
            return null;
        }

        return ((Number)number).longValue();
    }
    public static List<UserDTO> mapUserToUserDTO(List<User> users) {
        List<UserDTO> userDTOS = new ArrayList<UserDTO>();
        for(User user : users) {
            //TODO Setter-e in loc de constr
            UserDTO userDTO = new UserDTO();

            userDTO.setId(user.getId());
            userDTO.setUsername(user.getUsername());
            userDTO.setPassword(user.getPassword());
            userDTO.setRoleName(user.getRole().getName());

            userDTOS.add(userDTO);
        }
        return userDTOS;
    }

    public static List<RoleDTO> mapRoleToRoleDTO(List<Role> roles) {
        List<RoleDTO> roleDTOS = new ArrayList<RoleDTO>();
        for(Role role: roles) {
            RoleDTO roleDTO = new RoleDTO();

            roleDTO.setId(role.getId());
            roleDTO.setName(role.getName());

            roleDTOS.add(roleDTO);
        }
        return roleDTOS;
    }
}
